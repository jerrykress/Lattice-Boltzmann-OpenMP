# Add any `module load` or `export` commands that your code needs to
# compile and run to this file.

module load libs/cuda/10.0-gcc-5.4.0-2.26
module load languages/anaconda2
module load languages/intel
